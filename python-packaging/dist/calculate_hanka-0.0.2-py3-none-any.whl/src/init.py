#!/user/bin/env python3

# __init__.py
from .stats import flip_coin
from .stats import roll_die


